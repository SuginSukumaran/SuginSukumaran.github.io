.. Oop Docs documentation master file, created by
   sphinx-quickstart on Tue Mar 18 22:13:14 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Software User guide
===================


.. toctree::
   :maxdepth: 8
   :caption: Contents

   introduction
   Prerequisites
   guide

.. toctree::
   :maxdepth: 8
   :caption: UI INTEGRATION

   gui

.. toctree::
   :maxdepth: 8
   :caption: MODULES AND FUNCTIONS

   modules